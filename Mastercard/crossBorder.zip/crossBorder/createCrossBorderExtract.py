# -*- coding: utf-8 -*-
"""
Take the raw Cross-Border data and format it properly for analysis.
For each Issuing Country:
    - get the Top 5 Merchant Countries by Volume
    - lump together all the other Merchant Countries, setting Merchant Country to "Other"
    For the Top 5 Issuing-Merchant combinations:
        write out "Value" and "Normalized Value" for each driver
    For the "Other" combination:
        write out aggregated "Value" and "Normalized Value" for each driver
    
    "Driver" consists of Issuing Country/Merchant Country/Program/Measure/CardPresence
"""

__author__ = 'The Hackett Group'

import numpy as np
import pandas as pd
from getConfig  import getConfig
from getData    import getData

DELIM = ","
TopX = 5

def sortByVolume(df):
    '''
    For each Issuing Country, sort the Merchant Countries by Volume
    '''
    volSort = df.groupby(level=[0,1])["Normalized Value"].sum()
    volSort = volSort.to_frame()
    volSort.columns = ["Volume"]
    volSort.reset_index(inplace=True)
    return volSort.sort_values(["Issuing Country", "Volume"], ascending=[True, False])

def writeRec(d, row):
    rec = d["issuer"]+DELIM+d["merchant"]+\
    DELIM+d["Program"]+\
    DELIM+d["Measure"]+DELIM+d["CardPresence"]+\
    DELIM+d["Period"]+\
    DELIM+str(row["Value"])+\
    DELIM+str(row["Normalized Value"])+"\n"
    output.write(rec)
    
def processTop(d, row):
    '''
    Get all the data for the passed in Issuer-Merchant combination
    Write out each line item for the combination
    '''
    d["merchant"] = row["Merchant Country"]
    tmp = df.loc[(d["issuer"], d["merchant"])]
    tmp.fillna(value=0, inplace=True)
    for idx, row in tmp.iterrows():
        d["Period"] = row["Period"]
        d["Program"] = row["Program"]
        d["Measure"] = row["Measure"]
        d["CardPresence"] = row["CardPresence"]
        writeRec(d, row)
        
def processOther(d, otherMerchants):
    '''We just processed the Top 5, now aggregate all the remaining Merchant Countries 
    into "Other" category
    - "index.isin" will look at the entire dataset and get only the Issuing-Merchant combinations
    for the "other" category. ("l" is the list of Issuing-Merchant combinations)
    - Once you have a DF of just the "others", then index it by the unique key of Issuing Country,
    Program, Measure and Card
    - That will allow "groupby" to aggregate the two values we're interested in, by key
    - Loop over the "grp": each row is an index key with the aggregated values
    '''
    d["merchant"] = "Other"
    otherMerchants.reset_index(inplace=True)
    otherMerchants.set_index(["Issuing Country", "Merchant Country"], inplace=True)
    l = list(otherMerchants.index.values)
    tmp = df.loc[df.index.isin(l)]
    
    tmp.reset_index(inplace=True)
    tmp.set_index(["Issuing Country", "Program", "Measure", "CardPresence", "Period"],\
                 inplace=True)
    grp = tmp.groupby(level=[0,1,2,3,4])[["Value", "Normalized Value"]].sum()
    for key, row in grp.iterrows():
        d["Program"] = key[1]
        d["Measure"] = key[2]
        d["CardPresence"] = key[3]
        d["Period"] = key[4]
        d["Value"] = row["Value"]
        d["Normalized Value"] = row["Normalized Value"]
        writeRec(d, row)
    
def processIssuer(issuer, volSort):
    ''' For each Issuer, extract the Top 5, then all the rest as "Others" '''
    d = {}
    d["issuer"] = issuer
    topMerchants = volSort.loc[issuer][:TopX]
    topMerchants.reset_index(drop=False, inplace=True)
    for _, row in topMerchants.iterrows():
        processTop(d, row)
    otherMerchants = volSort.loc[issuer][TopX:]
    processOther(d, otherMerchants)
    
def writeHdr(output):
    hdr = "Issuer"+DELIM+"Merchant"+DELIM+"Program"+DELIM+"Measure"+\
    DELIM+"CardPresence"+DELIM+"Period"+DELIM+"Value"+DELIM+"Normalized Value"+"\n"
    output.write(hdr)
    
if __name__ == "__main__":
    config = getConfig()
    
    df = getData(config, "\t")
    df.set_index(["Issuing Country", "Merchant Country"], inplace=True)
    
    volSort = sortByVolume(df)
    
    # Get all of the Issuing Countries, then process each one
    volSort.set_index(["Issuing Country"], inplace=True)
    issuers = np.unique(volSort.index.values)
    
    with open("/home/tbrownex/Will-v2.csv", "w") as output:
        writeHdr(output)
        for issuer in issuers:
            processIssuer(issuer, volSort)